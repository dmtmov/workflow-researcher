from tyk.decorators import *
from gateway import TykGateway as tyk

@Hook
def PreHook(request, session, spec):
    tyk.log("dima", "info")
    tyk.log("PreHook is called", "info")
    # Inject a header:
    request.add_header("testheader", "testvalue")
    return request, session

@Hook
def PostHook(request, session, spec):
    tyk.log("PostHook is called", "info")
    return request, session

@Hook
def ResponseHook(request, response, session, metadata, spec):
    tyk.log("ResponseHook is called", "info")
    # In this hook we have access to the response object, to inspect it, uncomment the following line:
    # print(response)
    tyk.log("ResponseHook: upstream returned {0}".format(response.status_code), "info")
    return response
